import tkinter as tk
from tkinter import messagebox

class MainWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Main Window")
        self.master.geometry("1200x800")

        # Label
        self.label = tk.Label(self.master, text="Welcome to a Picture of Cats")
        self.label.pack(pady=10)

        # Image
        self.image1 = tk.PhotoImage(file="cutecats.PNG")
        self.image_label = tk.Label(self.master, text="Cute cats", image=self.image1, compound=tk.TOP)
        self.image_label.image = self.image1  # Retain a reference to the image to prevent garbage collection
        self.image_label.pack()

        # Buttons
        self.open_window_button = tk.Button(self.master, text="Open Second Window", command=self.open_second_window)
        self.open_window_button.pack(pady=5)

        self.show_image_button = tk.Button(self.master, text="Click here to see a message", command=self.show_image)
        self.show_image_button.pack(pady=5)

        self.exit_button = tk.Button(self.master, text="Exit", command=self.exit_application)
        self.exit_button.pack(pady=5)

    def open_second_window(self):
        second_window = tk.Toplevel(self.master)
        SecondWindow(second_window)

    def show_image(self):
        messagebox.showinfo("Image Info", "Press ok if this button is working")

    def exit_application(self):
        self.master.destroy()

class SecondWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Second Window")
        self.master.geometry("800x500")

        # Label
        self.label = tk.Label(self.master, text="This is Another Cat")
        self.label.pack(pady=10)

        # Image
        self.image2 = tk.PhotoImage(file="cutecat.PNG")
        self.image_label = tk.Label(self.master, text="Another cute cat", image=self.image2, compound=tk.TOP)
        self.image_label.image = self.image2  # Retain a reference to the image to prevent garbage collection
        self.image_label.pack()

        # Button
        self.close_button = tk.Button(self.master, text="Close", command=self.close_window)
        self.close_button.pack(pady=5)

    def close_window(self):
        self.master.destroy()

def main():
    root = tk.Tk()
    app = MainWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()